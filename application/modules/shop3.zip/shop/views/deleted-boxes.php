<?php include APPPATH.'views/html/header.php'; ?>
	<section id="main-content">
		<section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading text-center">
                            <strong>Final Delete</strong>
                        </header>
                        <div class="panel-body" id="transfer_list">
                            <?php
                            if($this->session->flashdata('warning'))
                            {
                              ?>
                              <div class="alert alert-warning fade in">
                                <button data-dismiss="alert" class="close close-sm" type="button">
                                    <i class="icon-remove"></i>
                                </button>
                                <strong>Warning!</strong> <?=$this->session->flashdata('warning'); ?>
                              </div>
                              <?php
                            }                                  
                            if($this->session->flashdata('error'))
                            {
                              ?>
                              <div class="alert alert-block alert-danger fade in">
                                <button data-dismiss="alert" class="close close-sm" type="button">
                                    <i class="icon-remove"></i>
                                </button>
                                <strong>Oops sorry!</strong> <?=$this->session->flashdata('error'); ?>
                            </div>
                              <?php
                            }
                            if($this->session->flashdata('success'))
                            {
                              ?>
                              <div class="alert alert-success alert-block fade in">
                                  <button data-dismiss="alert" class="close close-sm" type="button">
                                      <i class="icon-remove"></i>
                                  </button>
                                  <h4>
                                      <i class="icon-ok-sign"></i>
                                      Success!
                                  </h4>
                                  <p><?=$this->session->flashdata('success'); ?></p>
                              </div>
                              <?php
                            }
                            ?>
                            <div class="table-responsive">
                                <table class="table table-bordered dataTables">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Box no</th>
                                            <th>Supplier</th>
                                            <th>Sup.DC.no</th>
                                            <th>Item name/code</th>
                                            <th>Shade name/code</th>
                                            <th>Shade number</th>
                                            <th>Lot no</th>
                                            <th>#Boxes</th>
                                            <th>#Cones</th>
                                            <th>Gr.Wt</th>
                                            <th>Nt.Wt</th>
                                            <th>Total lot wise Qty</th>
                                            <th>Remarks</th>
                                            <th>Deleted by</th>
                                            <th>Date</th>
                                            <th>
                                                <label>
                                                    <input type="checkbox" id="select_all">
                                                    Select All
                                                </label>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sno = 1;
                                        ?>
                                        <?php if(sizeof($boxes) > 0): ?>
                                            <?php foreach($boxes as $box): ?>
                                                <tr>
                                                    <td><?php echo $sno++; ?></td>
                                                    <td><?php echo $box->box_prefix; ?><?php echo $box->box_no; ?></td>
                                                    <td><?php echo $box->sup_name; ?></td>
                                                    <td><?php echo $box->supplier_dc_no; ?></td>
                                                    <td><?php echo $box->item_name; ?>/<?php echo $box->item_id; ?></td>
                                                    <td><?php echo $box->shade_name; ?>/<?php echo $box->shade_id; ?></td>
                                                    <td><?php echo $box->shade_code; ?></td>
                                                    <td><?php echo $box->lot_no; ?></td>
                                                    <td><?php echo $box->no_boxes; ?></td>
                                                    <td><?php echo $box->no_cones; ?></td>
                                                    <td><?php echo $box->gr_weight; ?></td>
                                                    <td><?php echo $box->nt_weight; ?></td>
                                                    <td><?php echo $box->nt_weight; ?></td>
                                                    <td><?php echo $box->deleted_remarks; ?></td>
                                                    <td><?php echo $box->deleted_by; ?></td>
                                                    <td><?php echo date("d-m-Y H:i:s", strtotime($box->deleted_on)); ?></td>
                                                    <td>
                                                        <input type="checkbox" class="chkBoxId" value="<?php echo $box->box_id; ?>">                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <form class="form" method="post" action="<?php echo base_url('shop/packing/final_delete'); ?>">
                                    <input type="hidden" name="selected_boxes" id="selected_boxes">
                                    <button type="submit" class="btn btn-danger" name="submit" value="submit">Final Delete</button>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
		</section>
	</section>

<?php include APPPATH.'views/html/footer.php'; ?>
<script type="text/javascript">
    var oTable01 = $('.dataTables').dataTable({
        "sDom": "<'row'<'col-sm-6'l><'col-sm-6'f>r>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
        "sPaginationType": "bootstrap",
        "oLanguage": {
            "sLengthMenu": "_MENU_ records per page",
            "oPaginate": {
                "sPrevious": "Prev",
                "sNext": "Next"
            }
        }
    });
    jQuery('.dataTables_wrapper .dataTables_filter input').addClass("form-control");
    jQuery('.dataTables_wrapper .dataTables_length select').addClass("form-control");


    $(document).on('click', '#select_all', function(e){
        if(this.checked){
            $('tbody input[type="checkbox"]:not(:checked)').trigger('click');
        } else {
            $('tbody input[type="checkbox"]:checked').trigger('click');
        }
        e.stopPropagation();
    });

    $(document).on('click', "input[type='checkbox']", function(){
        var matches = [];
        var checkedcollection = oTable01.$(".chkBoxId:checked", { "page": "all" });
        checkedcollection.each(function (index, elem) {
            matches.push($(elem).val());
        });
        $("#selected_boxes").val(matches);
        // alert(matches);
    });
</script>
</body>
</html>